def main():
    print('Hi frsssssssssssssom my_package.')


if __name__ == '__main__':
    main()

# Cartographer Mapping Package

This package provides a launch file for running Cartographer SLAM in ROS 2.

## Installation

### Dependencies
Ensure the required dependencies are installed before running the package.

#### Install ROS 2 (if not already installed)
Refer to the official ROS 2 documentation for installation steps: [ROS 2 Installation Guide](https://docs.ros.org/)

#### Install Required Packages
Run the following commands to install dependencies, clone the package, and build it:
```bash
sudo apt update && sudo apt install -y \
    ros-jazzy-cartographer-ros \
    ros-jazzy-nav2-map-server
```

### Launching Cartographer Mapping

Run the launch file to start the mapping process:

```bash
ros2 launch cartographer_mapping mapping.launch.py use_sim_time:=false exploration:=true
```

### Viewing and Saving the Map

To visualize the generated map using RViz:

```bash
rviz2
```
In RViz, add the "Map" display and set the topic to /map.

To save the generated map:

```bash
ros2 run nav2_map_server map_saver_cli -f ~/map
```
This will save the map as map.pgm and map.yaml in your home directory.

### Parameters

| Parameter                         | Default Value | Description                                  |
|-----------------------------------|--------------|----------------------------------------------|
| `use_sim_time`                   | `False`      | Enable simulation time                      |
| `exploration`                     | `True`       | Run SLAM in exploration mode                |
| `resolution`                      | `0.05`       | Grid resolution                             |
| `publish_period_sec`              | `1.0`        | Publish period for occupancy grid updates   |
| `configuration_directory`         | Path to `config` | Directory containing `.lua` config files   |
| `slam_configuration_basename`     | `slam.lua`   | SLAM configuration file                     |
| `localization_configuration_basename` | `slam.lua` | Localization configuration file             |


### Notes
- Ensure that your `LiDAR` data is correctly published to `/scan`.

- Modify the `slam.lua` configuration file for **custom tuning**.